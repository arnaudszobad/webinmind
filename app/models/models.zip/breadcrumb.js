var BreadcrumbModel = DS.Model.extend({
  links: DS.hasMany('link',{async:true}),
  root:  DS.belongsTo('link',{async:true}),
  parent:DS.attr('number')
});

BreadcrumbModel.FIXTURES = [
  {
    id:1,
    root:1, // A
    links:[6,7], // AA - AB
    parent:0
  },
    {
      id:2,
      root:6, // AA
      links:[8,9],  // AAA - AAB
      parent:1 // A
    },
  {
    id:3,
    root:2, // B
    links:[10], // BA
    parent:0
  },
  {
    id:4,
    root:3, // C
    links:[11], // CA
    parent:0
  },
    {
      id:5,
      root:11, // CA
      links:[12], // CAA
      parent:4 // C
    },
      {
        id:6,
        root:12, // CAA
        links:[13], // CAAA
        parent:5 // CA
      }
  
];

export default BreadcrumbModel;